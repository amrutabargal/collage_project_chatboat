const container = document.querySelector(".container");   
const chatsContainer = document.querySelector(".chats-container");
const promptForm = document.querySelector(".prompt-form");
const promptInput = promptForm.querySelector(".prompt-input");
const fileInput = promptForm.querySelector("#file-input");
const fileUploadWrapper = promptForm.querySelector(".file-upload-wrapper");
const themeToggle = document.querySelector("#theme-toggle-btn");

const API_KEY = "AIzaSyC54y8EEr2BGbAh2NTeMzl7f1qcn60EUk4";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

let typingInterval, controller;
const chatHistory = [];
const userData = { message: "", file: {} };

const createMsgEelement = (content, ...classes) => {
  const div = document.createElement("div");
  div.classList.add("message", ...classes);
  div.innerHTML = content;
  return div;
};

const scrollToBottom = () => { 
  chatsContainer.scrollTo({ top: chatsContainer.scrollHeight, behavior: "smooth" });
};

const typingEffect = (text, textElement, botMsgDiv) => {
  textElement.textContent = "";
  const words = text.split(" ");
  let wordIndex = 0;
  typingInterval = setInterval(() => {
    if (wordIndex < words.length) {
      textElement.textContent += (wordIndex === 0 ? "" : " ") + words[wordIndex++];
      scrollToBottom();
    } else {
      clearInterval(typingInterval);
      botMsgDiv.classList.remove("loading");
      document.body.classList.remove("bot-responding");
    }
  }, 40);
};

const generateResponse = async (botMsgDiv) => {
  const textElement = botMsgDiv.querySelector(".message-text");
  controller = new AbortController();

  chatHistory.push({
    role: "user",
    parts: [
      { text: userData.message },
      ...(userData.file.data ? [{ inline_data: (({ fileName, isImage, ...rest }) => rest)(userData.file) }] : [])
    ]
  });

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: chatHistory }),
      signal: controller.signal
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error.message);

    const responseText = data.candidates[0].content.parts[0].text.replace(/\*\*([^*]+)\*\*/g, "$1").trim();
    typingEffect(responseText, textElement, botMsgDiv);
    chatHistory.push({ role: "model", parts: [{ text: responseText }] });
  } catch (error) {
    textElement.style.color = "#d62939";
    textElement.textContent = error.name === "AbortError" ? "Response generation stopped." : error.message;
    botMsgDiv.classList.remove("loading");
    document.body.classList.remove("bot-responding");
  } finally {
    userData.file = {};
  }
};

const handleFormSubmit = (e) => {
  e.preventDefault();
  const userMessage = promptInput.value.trim();
  if (!userMessage || document.body.classList.contains("bot-responding")) return;

  promptInput.value = "";
  userData.message = userMessage;
  document.body.classList.add("bot-responding", "chats-active");
  fileUploadWrapper.classList.remove("active", "img-attached", "file-attached");

  const userMsgHTML = `
    ${userData.file.data ? (userData.file.isImage
      ? `<img src="data:${userData.file.mime_type};base64,${userData.file.data}" class="img-attachment" />`
      : `<p class="file-attachment"><span class="material-symbols-rounded">description</span>${userData.file.fileName}</p>`) : ""}
    <p class="message-text"></p>
  `;

  const userMsgDiv = createMsgEelement(userMsgHTML, "user-message");
  userMsgDiv.querySelector(".message-text").textContent = userMessage;
  chatsContainer.appendChild(userMsgDiv);
  scrollToBottom();

  setTimeout(() => {
    const botMsgHTML = `
      <div class="message-text">
        <img src="logo.png" alt="AI Avatar" class="avatar">
        <p class="message-text">Just a sec...</p>
      </div>`;

    const botMsgDiv = createMsgEelement(botMsgHTML, "bot-message", "loading");
    chatsContainer.appendChild(botMsgDiv);
    scrollToBottom();
    generateResponse(botMsgDiv);
  }, 600);
};

fileInput.addEventListener("change", () => {
  const file = fileInput.files[0];
  if (!file) return;
  const isImage = file.type.startsWith("image/");
  const reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onload = (e) => {
    fileInput.value = "";
    const base64String = e.target.result.split(",")[1];
    fileUploadWrapper.querySelector(".file-preview").src = e.target.result;
    fileUploadWrapper.classList.add("active", isImage ? "img-attached" : "file-attached");
    userData.file = { fileName: file.name, data: base64String, mime_type: file.type, isImage };
  };
});

document.querySelector("#cancel-file-btn").addEventListener("click", () => {
  userData.file = {};
  fileUploadWrapper.classList.remove("active", "img-attached", "file-attached");
  fileUploadWrapper.querySelector(".file-preview").src = "#";
});

document.querySelector("#stop-response-btn").addEventListener("click", () => {
  userData.file = {};
  controller?.abort();
  clearInterval(typingInterval);
  chatsContainer.querySelector(".bot-message.loading")?.classList.remove("loading");
  document.body.classList.remove("bot-responding");
});

document.querySelector("#delete-chats-btn").addEventListener("click", () => {
  chatHistory.length = 0;
  chatsContainer.innerHTML = "";
  document.body.classList.remove("bot-responding", "chats-active");
});

document.querySelectorAll(".suggestions-item").forEach(item => {
  item.addEventListener("click", () => {
    const imagePrompt = item.dataset.imagePrompt;
    if (imagePrompt) {
      generateImageFromPrompt(imagePrompt);
    } else {
      promptInput.value = item.querySelector(".text").textContent;
      promptForm.dispatchEvent(new Event("submit"));
    }
  });
});

themeToggle.addEventListener("click", () => {
  const isLightTheme = document.body.classList.toggle("light-theme");
  localStorage.setItem("themeColor", isLightTheme ? "light_mode" : "dark_mode");
  themeToggle.textContent = isLightTheme ? "dark_mode" : "light_mode";
});

const isLightTheme = localStorage.getItem("themeColor") === "light_mode";
document.body.classList.toggle("light-theme", isLightTheme);
themeToggle.textContent = isLightTheme ? "dark_mode" : "light_mode";

promptForm.addEventListener("submit", handleFormSubmit);
promptForm.querySelector("#add-file-btn").addEventListener("click", () => fileInput.click());

promptInput.addEventListener("paste", (event) => {
  const items = event.clipboardData?.items || [];
  for (let item of items) {
    if (item.type.startsWith("image/")) {
      const file = item.getAsFile();
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        const base64String = e.target.result.split(",")[1];
        const mimeType = file.type;
        const preview = fileUploadWrapper.querySelector(".file-preview");
        preview.src = e.target.result;
        fileUploadWrapper.classList.add("active", "img-attached");
        userData.file = {
          fileName: "pasted-image.png",
          data: base64String,
          mime_type: mimeType,
          isImage: true
        };
      };
    }
  }
});

async function generateImageFromPrompt(prompt) {
  const botMsgDiv = createMsgEelement(`<p class="message-text">Generating image...</p>`, "bot-message", "loading");
  chatsContainer.appendChild(botMsgDiv);
  scrollToBottom();
  try {
    const response = await fetch("https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2", {
      method: "POST",
      headers: {
        Authorization: "Bearer YOUR_HUGGINGFACE_API_KEY",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ inputs: prompt })
    });
    const blob = await response.blob();
    const imageURL = URL.createObjectURL(blob);
    botMsgDiv.classList.remove("loading");
    botMsgDiv.innerHTML = `<img src="${imageURL}" alt="Generated Image" style="max-width: 300px; border-radius: 8px;" />`;
    scrollToBottom();
  } catch (err) {
    botMsgDiv.classList.remove("loading");
    botMsgDiv.innerHTML = `<p class="message-text" style="color: red;">Image generation failed: ${err.message}</p>`;
  }
}

// ✅ Resume Builder Logic - Updated with proper API integration


/* ---------- Modal open / close ---------- */
document.getElementById("resume-builder-btn").addEventListener("click", () => {
  document.getElementById("resume-builder-modal").style.display = "block";
});
document.querySelector("#resume-builder-modal .close-btn").addEventListener("click", () => {
  document.getElementById("resume-builder-modal").style.display = "none";
});

/* ---------- Template‑tab toggle ---------- */
document.getElementById("template-tab-btn").addEventListener("click", () => {
  const tab = document.getElementById("template-tab");
  tab.style.display = tab.style.display === "none" ? "block" : "none";
});

/* ---------- Card <‑‑> hidden <select> sync ---------- */
function syncTemplate(value) {
  document.getElementById("template-selector").value = value;          // radio → select
  document.querySelectorAll(".template-card").forEach(card => {        // highlight
    card.style.border = card.querySelector("input").value === value
      ? "2px solid #007bff"
      : "2px solid #ccc";
  });
}
document.querySelectorAll(".template-card input[type='radio']")
  .forEach(radio => radio.addEventListener("change", () => syncTemplate(radio.value)));

/* also allow programmatic change (if you ever set #template-selector) */
document.getElementById("template-selector").addEventListener("change", e => {
  const v = e.target.value;
  document.querySelector(`.template-card input[value='${v}']`).checked = true;
  syncTemplate(v);
});

/* ---------- Generate resume ---------- */
function generateResume() {
  const name        = document.getElementById("name").value;
  const email       = document.getElementById("email").value;
  const phone       = document.getElementById("phone").value;
  const linkedin    = document.getElementById("linkedin").value;
  const summary     = document.getElementById("summary").value;
  const education   = document.getElementById("education").value;
  const experience  = document.getElementById("experience").value;
  const skills      = document.getElementById("skills").value;
  const template    = document.getElementById("template-selector").value || "template1";

  /* helper to break lines */
  const br = txt => txt.replace(/\n/g, "<br>");

  /* ---------- common blocks ---------- */
  const headBlock = `
    <p><strong>Email:</strong> ${email}</p>
    <p><strong>Phone:</strong> ${phone}</p>
    ${linkedin ? `<p><strong>LinkedIn:</strong> <a href="${linkedin}" target="_blank">${linkedin}</a></p>` : ""}
  `;
  const bodyBlocks = `
    <h3>Summary</h3><p>${br(summary)}</p>
    <h3>Education</h3><p>${br(education)}</p>
    <h3>Experience</h3><p>${br(experience)}</p>
    <h3>Skills</h3><p>${br(skills)}</p>
  `;

  let resumeHTML = "";

  /* ---------- Template variations ---------- */
  switch (template) {
    case "template2":          /* Bold header (dark) */
      resumeHTML = `
        <div style="font-family: Arial, sans-serif; max-width:800px; margin:auto;">
          <header style="background:#1a1a1a;color:#fff;padding:20px;">
            <h2 style="margin:0;">${name}</h2>
            <p>${email} | ${phone} ${linkedin ? `| ${linkedin}` : ""}</p>
          </header>
          <main style="padding:20px;">${bodyBlocks}</main>
        </div>
      `;
      break;

    case "template3":          /* Two column */
      resumeHTML = `
        <div style="display:flex;font-family:Arial,sans-serif;max-width:800px;margin:auto;">
          <aside style="width:30%;padding:20px;background:#f4f4f4;">
            <h2>${name}</h2>${headBlock}
            <h3>Skills</h3><p>${br(skills)}</p>
          </aside>
          <main style="width:70%;padding:20px;">${bodyBlocks}</main>
        </div>
      `;
      break;L
  
    case "template4":          /* Modern Blue */
      resumeHTML = `
        <div style="font-family:Arial,sans-serif;max-width:800px;margin:auto;border:2px solid #3498db;">
          <header style="background:#3498db;color:#fff;padding:15px;">
            <h2 style="margin:0;">${name}</h2>
          </header>
          <section style="padding:20px;">${headBlock}</section>
          <section style="padding:20px;">${bodyBlocks}</section>
        </div>
      `;v  
      break;

    case "template5":          /* Minimalist */
      resumeHTML = `
        <div style="font-family:Georgia,serif;max-width:700px;margin:auto;padding:20px;">
          <h2 style="border-bottom:1px solid #000;padding-bottom:5px;">${name}</h2>
          ${headBlock}
          ${bodyBlocks}
        </div>
      `;
      break;

    case "template6":          /* Creative layout */
      resumeHTML = `
        <div style="font-family:'Trebuchet MS',sans-serif;max-width:800px;margin:auto;">
          <header style="text-align:center;padding:30px 0;background:linear-gradient(135deg,#00c6ff,#0072ff);color:#fff;">
            <h1 style="margin:0;">${name}</h1>
            <p>${email} | ${phone}${linkedin ? ` | ${linkedin}` : ""}</p>
          </header>
          <div style="display:grid;grid-template-columns:35% 65%;gap:20px;padding:25px;">
            <div>
              <h3>Skills</h3><p>${br(skills)}</p>
            </div>
            <div>${bodyBlocks}</div>
          </div>
        </div>
      `;
      break;

    default:                   /* Template 1 – Clean ATS */
      resumeHTML = `
        <div style="font-family:Arial,sans-serif;max-width:800px;margin:auto;padding:20px;">
          <h2 style="color:#2c3e50;padding-bottom:10px;">${name}</h2>
          ${headBlock}
          ${bodyBlocks}
        </div>
      `;
  }

  document.getElementById("resume-output").innerHTML = resumeHTML;
  extendResumeSections();   // add certifications & projects
}

/* ---------- Append certifications & projects ---------- */
// function extendResumeSections() {
//   const resumeContainer = document.getElementById("resume-output");
//   const certifications = document.getElementById("certifications").value.trim();
//   const projects       = document.getElementById("projects").value.trim();

//   let extra = "";
//   if (certifications) {
//     extra += `<h3>Certifications</h3><ul>${certifications.split("\n").map(c=>`<li>${c}</li>`).join("")}</ul>`;
//   }
//   if (projects) {
//     extra += `<h3>Projects</h3><ul>${projects.split("\n").map(p=>`<li>${p}</li>`).join("")}</ul>`;
//   }
//   resumeContainer.innerHTML += extra;
// }

function extendResumeSections() {
  const resumeContainer = document.getElementById("resume-output");
  const certifications = document.getElementById("certifications").value.trim();
  const projects = document.getElementById("projects").value.trim();

  let extra = "";

  // Handle Certifications
  if (certifications) {
    extra += `<h3>Certifications</h3><ul>${certifications
      .split("\n")
      .map(c => `<li>${c}</li>`)
      .join("")}</ul>`;
  }

  // Handle Multiple Projects
  if (projects) {
    extra += `<h3>Projects</h3><div>`;
    const projectBlocks = projects.split(/\n\s*\n/); // Split on double newline

    projectBlocks.forEach(p => {
      const lines = p.trim().split("\n").map(line => line.trim());
      if (lines.length >= 1) {
        const title = lines[0];
        const tech = lines[1] ? `<em>${lines[1]}</em>` : "";
        const description = lines.slice(2).join(" ");
        extra += `
          <div style="margin-bottom: 12px;">
            <strong>${title}</strong><br/>
            ${tech ? `${tech}<br/>` : ""}
            <span>${description}</span>
          </div>`;
      }
    });

    extra += `</div>`;
  }

  // Add to resume container
  resumeContainer.innerHTML += extra;
} 


/* ---------- Print / save ---------- */
function printResume() {
  const content = document.getElementById("resume-output").innerHTML;
  const win = window.open("","","width=800,height=600");
  win.document.write(`<html><head><title>Resume</title><style>body{font-family:Arial;margin:20px;}</style></head><body>${content}</body></html>`);
  win.document.close();
  win.print();
}

/* ---------- AI (Cohere) helpers – unchanged ---------- */
// async function generateSkills() {
//   const jobTitle = document.getElementById("jobTitle").value.trim();
//   if (!jobTitle) return alert("Please enter your job title.");
//   const apiKey = "zJzS8yqGTcJaVLWFayinVyLkp11t1uLOAIF2x0L5";
//   const message = `List top 5 professional skills (technical and soft) for a ${jobTitle}. Format:\\n- Skill 1\\n- Skill 2`;
//   const response = await fetch("https://api.cohere.ai/v1/chat", {
//     method:"POST",
//     headers:{ "Authorization":`Bearer ${apiKey}`, "Content-Type":"application/json" },
//     body:JSON.stringify({ model:"command-r", message, chat_history:[], temperature:0.7 })
//   });
//   const data = await response.json();
//   if (data?.text) {
//     document.getElementById("skills").value = data.text.trim();
//     alert("Skills generated!");
//   } else alert("Error generating skills.");
// }
async function generateSkills() {
  const jobTitle = document.getElementById("jobTitle").value.trim();
  if (!jobTitle) return alert("Please enter your job title.");

  const apiKey = "zJzS8yqGTcJaVLWFayinVyLkp11t1uLOAIF2x0L5";

  const message = `Act as a professional resume writer. Based on the job title "${jobTitle}", list the top 5 relevant skills (a mix of technical and soft skills) in a clean resume section format like this:

SKILLS
- Skill 1
- Skill 2
- Skill 3
- Skill 4
- Skill 5

Only return the SKILLS section without any extra explanation.`;

  const response = await fetch("https://api.cohere.ai/v1/chat", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "command-r",
      message,
      chat_history: [],
      temperature: 0.5
    })
  });

  const data = await response.json();

  if (data?.text) {
    document.getElementById("skills").value = data.text.trim();
    alert("Skills generated in resume format!");
  } else {
    alert("Error generating skills. Please try again.");
  }
}

async function generateSummary() {
  const jobTitle = document.getElementById("jobTitle").value.trim();
  if (!jobTitle) return alert("Please enter your job title.");
  const apiKey = "zJzS8yqGTcJaVLWFayinVyLkp11t1uLOAIF2x0L5";
  const message = `Write a professional 2-sentence summary for a ${jobTitle}.`;
  const response = await fetch("https://api.cohere.ai/v1/chat", {
    method:"POST",
    headers:{ "Authorization":`Bearer ${apiKey}`, "Content-Type":"application/json" },
    body:JSON.stringify({ model:"command-r", message, chat_history:[], temperature:0.7 })
  });
  const data = await response.json();
  if (data?.text) {
    document.getElementById("summary").value = data.text.trim();
    alert("Summary generated!");
  } else alert("Error generating summary.");
}


/* ---------- Download Resume as Word ---------- */
function downloadWordResume() {
  const content = document.getElementById("resume-output").innerHTML;
  const header = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office' 
          xmlns:w='urn:schemas-microsoft-com:office:word' 
          xmlns='http://www.w3.org/TR/REC-html40'>
    <head><meta charset='utf-8'><title>Resume</title></head><body>`;
  const footer = `</body></html>`;
  const sourceHTML = header + content + footer;

  const blob = new Blob(['\ufeff', sourceHTML], {
    type: 'application/msword'
  });

  const downloadLink = document.createElement("a");
  downloadLink.href = URL.createObjectURL(blob);
  downloadLink.download = "My_Resume.doc";
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
}

/* ---------- ATS Optimization Check ---------- */
function checkATS() {
  const jobTitle = document.getElementById("jobTitle").value.toLowerCase();
  const summary = document.getElementById("summary").value.trim();
  const skills = document.getElementById("skills").value.toLowerCase();
  const experience = document.getElementById("experience").value.trim();
  const education = document.getElementById("education").value.trim();

  let issues = [];

  if (summary.length < 100) {
    issues.push("⚠️ Your summary is quite short. Consider elaborating it to at least 2–3 lines.");
  }

  if (!skills.includes(jobTitle.split(" ")[0])) {
    issues.push("⚠️ Your skills don't seem to include key job title keywords.");
  }

  if (!experience.toLowerCase().includes(jobTitle.split(" ")[0])) {
    issues.push("⚠️ Your experience section is missing role-related terms.");
  }

  if (!education) {
    issues.push("⚠️ Add your educational background. ATS often checks for degrees.");
  }

  const feedbackBox = document.createElement("div");
  feedbackBox.style.border = "1px solid #aaa";
  feedbackBox.style.padding = "15px";
  feedbackBox.style.background = "#fdfce7";
  feedbackBox.style.marginTop = "20px";
  feedbackBox.style.borderRadius = "8px";

  feedbackBox.innerHTML = issues.length === 0
    ? "<strong>✅ Your resume is ATS-friendly!</strong>"
    : `<strong>ATS Suggestions:</strong><ul>${issues.map(i => `<li>${i}</li>`).join("")}</ul>`;

  const prevBox = document.getElementById("resume-preview");
  const existing = document.getElementById("ats-feedback-box");
  if (existing) existing.remove();
  feedbackBox.id = "ats-feedback-box";
  prevBox.appendChild(feedbackBox);
}
